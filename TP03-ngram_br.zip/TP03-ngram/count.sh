#!/bin/bash

filename=$1

echo -n "<s> " > out.txt
sed -z 's/\n/\<\/s\>\n\<s\>\ /g' $1 >> out.txt
sed -i '$ d' out.txt
cat out.txt